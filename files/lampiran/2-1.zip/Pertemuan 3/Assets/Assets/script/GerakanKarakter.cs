﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GerakanKarakter : MonoBehaviour {

	// Property
	public float speed = 5.0f;
	public float jumpSpeed = 5.0f;
	public bool isGround = false;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		//default control
		//transform.Translate (Input.GetAxis ("Horizontal"), 0, Input.GetAxis ("Vertical"));

		//
		Vector3 x = Input.GetAxis("Horizontal") * transform.right * Time.deltaTime * speed;
		Vector3 z = Input.GetAxis ("Vertical") * transform.forward * Time.deltaTime * speed;

		transform.Translate (x + z);
		transform.rotation = Quaternion.LookRotation (Vector3.forward, Vector3.up);

		if (Input.GetKeyDown(KeyCode.Space)) {
			Jump ();
		}
	}

	void Jump() {
		if (isGround){
			GetComponent<Rigidbody> ().AddForce (transform.up * jumpSpeed, ForceMode.Impulse);
			isGround = false;
		}
	}

	void OnCollisionEnter(Collision hit){
		print ("Collision Detected!!!");
		isGround = true;
	}
}
